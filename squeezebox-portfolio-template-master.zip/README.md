Squeezebox Portfolio Template
=========

An intro block that slides out to uncover a gallery of portfolio items.

[Article on CodyHouse](http://codyhouse.co/gem/squeezebox-portfolio-template/)

[Demo](http://codyhouse.co/demo/squeezebox-portfolio-template/index.html)
 
[Terms](http://codyhouse.co/terms/)
